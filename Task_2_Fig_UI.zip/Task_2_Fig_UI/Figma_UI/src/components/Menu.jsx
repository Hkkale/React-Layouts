import React from 'react'

const Menu = () => {
  return (
    <div className='h-14/17 w-full flex justify-center items-center border rounded-2xl mt-5 bg-white'>

      <h1 className='font-bold text-6xl'  style={{fontFamily:"Syne"}}>Menu Component</h1>
      
    </div>
  )
}

export default Menu
